package com.freshdesk.httpclient3x;

/**
 *
 * @author subhash
 */
public class APITokenEndpoint {
    static final String apiToken = "YOURTOKEN";
    static final String apiEndpoint = "http://YOURDOMAIN.freshdesk.com";
}
